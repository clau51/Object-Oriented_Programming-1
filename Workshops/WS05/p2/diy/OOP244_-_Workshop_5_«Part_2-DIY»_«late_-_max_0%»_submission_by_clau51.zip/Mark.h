//Name: Carmen Lau
//Student ID: 166689216
//Email: clau51@myseneca.ca
//Date: October 20, 2022
//Section: NBB
//I have done all the coding by myself and only copied the code that my professor provided to complete my workshops and assignments.

#ifndef SDDS_MARK_H_
#define SDDS_MARK_H_

namespace sdds
{
	class Mark
	{
	private:
		int m_mark;

		// Validates a mark
		bool validate(int mark)const;
	public:
		
		// Constructor: sets mark if valid
		Mark(int mark = 0);

		// Sets Mark to an invalid state
		Mark& setInvalid();

		// The int type conversion overload - if m_mark is valid, return m_mark, else return 0
		operator int()const;

		// The double type conversion overload that returns different gpa values depending on m_mark.
		operator double()const;

		// The char type conversion overload - depending on m_mark, will return different gpa values
		operator char()const;

		// The bool conversion type overload - returns true if m_mark is valid
		operator bool()const;

		// Checks if both operands are equal (both of type Mark)
		bool operator==(const Mark& mark)const;

		// Checks if both operands are not equal (both of type Mark)
		bool operator!=(const Mark& mark)const;

		// Checks if left operand is less than right operand (both of type Mark)
		bool operator<(const Mark& mark)const;

		// Checks if left operand is greater than right operand (both of type Mark)
		bool operator>(const Mark& mark)const;

		// Checks if left operand is less than or equal to right operand (both of type Mark)
		bool operator<=(const Mark& mark)const;

		// Checks if left operand is greater than or equal to right operand (both of type Mark)
		bool operator>=(const Mark& mark)const;

		// Unary pre-fix operator for pre-increment for an object of Mark type
		Mark& operator++();

		// Unary post-fix operator for post-increment for an object of Mark type
		Mark operator++(int);

		// Unary pre-fix operator for pre-decrement for an object of Mark type
		Mark& operator--();

		// Unary post-fix operator for post-decrement for an object of Mark type
		Mark operator--(int);

		// Checks if mark passes
		bool operator~();

		// Set Mark object to integer using assignment operator
		Mark& operator=(int num);

		// An integer can be added to value of mark
		Mark& operator+=(int num);

		// An integer can be subtracted to value of mark
		Mark& operator-=(int num);

		// Query - get mark
		int getMark()const;

		// Two mark objects can be added together
		Mark operator+(const Mark& mark)const;

		// A mark object can be added to an int
		Mark operator+(int num)const;

		// Move right operand to left operand and set source to 0 (of Mark type)
		Mark& operator<<(Mark& mark);

		// Move left operand to right operand and set source to 0 (of Mark type)
		Mark& operator>>(Mark& mark);
	};

	// Helper - A mark's value can be added to an integer 
	int& operator+=(int& num, const Mark& mark);

	// Helper - A mark's value can be subtracted to an integer
	int& operator-=(int& num, const Mark& mark);

	// Helper - An integer can be added to a Mark object
	int operator+(int& num, const Mark& mark);
}

#endif