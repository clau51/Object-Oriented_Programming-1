//Name: Carmen Lau
//Student ID: 166689216
//Email: clau51@myseneca.ca
//Date: October 20, 2022
//Section: NBB
//I have done all the coding by myself and only copied the code that my professor provided to complete my workshops and assignments.

#include "Mark.h"
#include <iostream>

namespace sdds
{
	// Validates a mark
	bool Mark::validate(int mark)const
	{
		return mark >= 0 && mark <= 100;
	}

	// Constructor: sets mark if valid
	Mark::Mark(int mark)
	{
		if (validate(mark))
		{
			m_mark = mark;
		}
		else
		{
			setInvalid();
		}
	}

	// Sets Mark to an invalid state
	Mark& Mark::setInvalid()
	{
		m_mark = -1;
		return *this;
	}

	// The int type conversion overload - if m_mark is valid, return m_mark, else return 0
	Mark::operator int()const
	{
		return validate(m_mark) ? m_mark : 0;
	}

	// The double type conversion overload that returns different gpa values depending on m_mark.
	Mark::operator double()const
	{
		double gpa = 0.0;

		if (m_mark >= 50 && m_mark < 60)
		{
			gpa = 1.0;
		}
		else if (m_mark >= 60 && m_mark < 70)
		{
			gpa = 2.0;
		}
		else if (m_mark >= 70 && m_mark < 80)
		{
			gpa = 3.0;
		}
		else if (m_mark >= 80 && m_mark <= 100)
		{
			gpa = 4.0;
		}

		return gpa;
	}

	// The char type conversion overload - depending on m_mark, will return different gpa values
	Mark::operator char()const
	{
		char gpa = 'X';

		if (m_mark >= 0 && m_mark < 50)
		{
			gpa = 'F';
		}
		else if (m_mark >= 50 && m_mark < 60)
		{
			gpa = 'D';
		}
		else if (m_mark >= 60 && m_mark < 70)
		{
			gpa = 'C';
		}
		else if (m_mark >= 70 && m_mark < 80)
		{
			gpa = 'B';
		}
		else if (m_mark >= 80 && m_mark <= 100)
		{
			gpa = 'A';
		}

		return gpa;
	}

	// The bool conversion type overload - returns true if m_mark is valid
	Mark::operator bool()const
	{
		return validate(m_mark);
	}

	// Checks if both operands are equal (both of type Mark)
	bool Mark::operator==(const Mark& mark)const
	{
		return *this && mark ? m_mark == mark.m_mark : false;
	}

	// Checks if both operands are not equal (both of type Mark)
	bool Mark::operator!=(const Mark& mark)const
	{
		return *this && mark ? m_mark != mark.m_mark : false;
	}

	// Checks if left operand is less than right operand (both of type Mark)
	bool Mark::operator<(const Mark& mark)const
	{
		return *this && mark ? m_mark < mark.m_mark : false;
	}

	// Checks if left operand is greater than right operand (both of type Mark)
	bool Mark::operator>(const Mark& mark)const
	{
		return *this && mark ? m_mark > mark.m_mark : false;

	}

	// Checks if left operand is less than or equal to right operand (both of type Mark)
	bool Mark::operator<=(const Mark& mark)const
	{
		return *this && mark ? m_mark <= mark.m_mark : false;

	}

	// Checks if left operand is greater than or equal to right operand (both of type Mark)
	bool Mark::operator>=(const Mark& mark)const
	{
		return *this && mark ? m_mark >= mark.m_mark : false;
	}

	// Unary pre-fix operator for pre-increment for an object of Mark type
	Mark& Mark::operator++()
	{
		int temp = m_mark;
		if (*this)
		{
			if (validate(++temp))
			{
				m_mark++;
			}
			else
			{
				setInvalid();
			}
		}

		return *this;
	}

	// Unary post-fix operator for post-increment for an object of Mark type
	Mark Mark::operator++(int)
	{
		int temp = m_mark;
		Mark old = *this;
		if (*this)
		{
			if (validate(++temp))
			{
				m_mark++;
			}
			else
			{
				setInvalid();
			}
		}

		return old;
	}

	// Unary pre-fix operator for pre-decrement for an object of Mark type
	Mark& Mark::operator--()
	{
		int temp = m_mark;
		if (*this)
		{
			if (validate(--temp))
			{
				m_mark--;
			}
			else
			{
				setInvalid();
			}
		}


		return *this;
	}

	// Unary post-fix operator for post-decrement for an object of Mark type
	Mark Mark::operator--(int)
	{
		int temp = m_mark;
		Mark old = *this;
		if (*this)
		{
			if (validate(--temp))
			{
				m_mark--;
			}
			else
			{
				setInvalid();
			}
		}

		return old;
	}

	// Checks if mark passes
	bool Mark::operator~()
	{
		return *this && (m_mark >= 50) ? true : false;
	}

	// Set Mark object to integer using assignment operator
	Mark& Mark::operator=(int num)
	{
		m_mark = num;
		if (!(*this))
		{
			setInvalid();
		}

		return *this;
	}

	// An integer can be added to value of mark
	Mark& Mark::operator+=(int num)
	{
		if (*this)
		{
			m_mark += num;
			if (!(*this))
			{
				setInvalid();
			}
		}

		return *this;
	}

	// An integer can be subtracted to value of mark
	Mark& Mark::operator-=(int num)
	{

		if (*this)
		{
			m_mark -= num;
			if (!(*this))
			{
				setInvalid();
			}
		}

		return *this;
	}

	// Query - get mark
	int Mark::getMark()const
	{
		return m_mark;
	}

	// Helper - A mark's value can be added to an integer 
	int& operator+=(int& num, const Mark& mark)
	{
		if (mark)
		{
			num += mark.getMark();
		}
		return num;
	}

	// Helper - A mark's value can be subtracted to an integer
	int& operator-=(int& num, const Mark& mark)
	{
		if (mark)
		{
			num -= mark.getMark();
		}
		return num;
	}

	// Two mark objects can be added together
	Mark Mark::operator+(const Mark& mark)const
	{
		Mark temp = *this;
		temp.m_mark += mark.m_mark;

		if (!temp)
		{
			temp.setInvalid();
		}

		return temp;
	}

	// A mark object can be added to an int
	Mark Mark::operator+(int num)const
	{
		Mark temp = *this;
		temp.m_mark += num;

		if (!temp)
		{
			temp.setInvalid();
		}

		return temp;
	}

	// Helper - An integer can be added to a Mark object
	//unclear on instructions whether or not there are restrictions (ie. max number)
	int operator+(int& num, const Mark& mark)
	{
		return num + mark.getMark();
	}

	// Move right operand to left operand and set source to 0 (of Mark type)
	Mark& Mark::operator<<(Mark& mark)
	{
		m_mark += mark.m_mark;
		mark.m_mark = 0;

		if (!mark)
		{
			mark.setInvalid();
		}

		return *this;
	}

	// Move left operand to right operand and set source to 0 (of Mark type)
	Mark& Mark::operator>>(Mark& mark)
	{

		mark.m_mark += m_mark;
		m_mark = 0;

		if (!mark)
		{
			mark.setInvalid();
		}

		return *this;
	}
}

